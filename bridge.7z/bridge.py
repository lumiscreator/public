import json
import time
import os
import requests

# Paths for data exchange
JSON_PATH = r"D:\MO2\Lumis\mods\LUMIS Development Output\SKSE\Plugins\StorageUtilData\Lumis_GPS.json"
GHOST_PATH = JSON_PATH.replace("Lumis_GPS.json", "Lumis_GHOSTS.json")

# REPLACE THIS with your actual server URL later
SERVER_URL = "http://127.0.0.1:5000/update" 

def read_local_gps():
    if os.path.exists(JSON_PATH):
        try:
            with open(JSON_PATH, 'r') as f:
                data = json.load(f)
                return {
                    "x": data.get("float", {}).get("x"),
                    "y": data.get("float", {}).get("y"),
                    "z": data.get("float", {}).get("z"),
                    "cell": data.get("int", {}).get("cell")
                }
        except: return None
    return None

def write_remote_ghost(ghost_data):
    """Atomic write to prevent Skyrim from reading a half-written file."""
    ghost_payload = {
        "float": {
            "ghost_x": ghost_data.get('x', 0),
            "ghost_y": ghost_data.get('y', 0),
            "ghost_z": ghost_data.get('z', 0)
        },
        "int": {
            "ghost_cell": ghost_data.get('cell', 0)
        }
    }
    temp_path = GHOST_PATH + ".tmp"
    try:
        with open(temp_path, 'w') as f:
            json.dump(ghost_payload, f)
        if os.path.exists(GHOST_PATH):
            os.remove(GHOST_PATH)
        os.rename(temp_path, GHOST_PATH)
        return True
    except OSError:
        return False

print("--- LUMIS MULTIVERSE BRIDGE: ONLINE ---")

try:
    while True:
        local_data = read_local_gps()
        
        if local_data and local_data['x'] is not None:
            try:
                # 1. SEND your data to the server
                # 2. RECEIVE the other player's data in the same response
                response = requests.post(SERVER_URL, json=local_data, timeout=1.5)
                
                if response.status_code == 200:
                    remote_player = response.json()
                    
                    if remote_player:
                        write_remote_ghost(remote_player)
                        print(f"[SYNC] Seeing Player at X: {int(remote_player['x'])} in Cell: {remote_player['cell']}")
                else:
                    print(f"[SERVER ERROR] Status: {response.status_code}")
                    
            except requests.exceptions.RequestException as e:
                print(f"[CONNECTION ERROR] Ensure server is running! {e}")
        
        time.sleep(1.0) 

except KeyboardInterrupt:
    print("\nBridge Stopped.")